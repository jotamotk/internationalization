export default {
  datasets: 'Datasets',
  models: 'Models',
  tasks: 'Tasks',
  welcome: 'Welcome to BasicAI!',
};
