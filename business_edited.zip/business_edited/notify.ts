export default {
  OnlyShowUnread: 'Only Show Unread',
  MarkAllAsRead: 'Mark All as Read',
  more: 'More >',
  Team: 'Team: ',
  Module: 'Module: ',
  Type: 'Type: ',
  TabTeam: 'Team',
  TabWhatIsNew: "What's New",
  NotAtTeam:
    'You are no longer a member of the {teamName} team. Would you like to delete all messages from the {teamName} team?',
  RedirectTeam: 'This message will redirect you to the {teamName} team. Do you wish to continue?',
};
