export default {
  datasetTips: 'Hover over the data and click "Annotate" to start!',
  CopyInstruction: 'Copy and open instruction',
  openTipsText:
    "Hello! I'd be glad to assist you in setting up Ontologies. Please feel free to chat with me",
};
